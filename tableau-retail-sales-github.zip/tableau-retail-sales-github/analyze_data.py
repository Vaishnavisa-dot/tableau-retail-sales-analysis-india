import pandas as pd

DATA_FILE = "Retail_Sales_India.csv"

df = pd.read_csv(DATA_FILE, parse_dates=["Order Date", "Ship Date"])

print("DATASET OVERVIEW")
print("-" * 50)
print(f"Rows: {len(df):,}")
print(f"Columns: {len(df.columns)}")
print(f"Unique orders: {df['Order ID'].nunique():,}")
print(f"Unique customers: {df['Customer ID'].nunique():,}")
print(f"Date range: {df['Order Date'].min().date()} to {df['Order Date'].max().date()}")
print(f"Missing cells: {int(df.isna().sum().sum())}")
print(f"Duplicate order IDs: {int(df['Order ID'].duplicated().sum())}")

sales = df["Sales"].sum()
profit = df["Profit"].sum()
orders = df["Order ID"].nunique()
print("\nKEY METRICS")
print("-" * 50)
print(f"Total sales: ₹{sales:,.2f}")
print(f"Total profit: ₹{profit:,.2f}")
print(f"Profit ratio: {profit / sales:.2%}" if sales else "Profit ratio: N/A")
print(f"Average order value: ₹{sales / orders:,.2f}" if orders else "Average order value: N/A")
print(f"Units sold: {df['Quantity'].sum():,}")
print(f"Average discount: {df['Discount'].mean():.2%}")
print(f"Average shipping days: {(df['Ship Date'] - df['Order Date']).dt.days.mean():.2f}")

print("\nSALES AND PROFIT BY CATEGORY")
print("-" * 50)
print(df.groupby("Category")[["Sales", "Profit"]].sum().sort_values("Sales", ascending=False).round(2))

print("\nSALES BY REGION")
print("-" * 50)
print(df.groupby("Region")[["Sales", "Profit"]].sum().sort_values("Sales", ascending=False).round(2))

print("\nDISCOUNT BAND ANALYSIS")
print("-" * 50)
bins = [-0.001, 0, 0.10, 0.20, 0.40]
labels = ["0% (No discount)", "1–10%", "11–20%", "21–40%"]
df["Discount Band"] = pd.cut(df["Discount"], bins=bins, labels=labels, include_lowest=True)
print(df.groupby("Discount Band", observed=False)[["Sales", "Profit"]].sum().round(2))

print("\nDATA QUALITY CHECKS")
print("-" * 50)
checks = {
    "Expected 1,200 rows": len(df) == 1200,
    "No missing values": not df.isna().any().any(),
    "Unique order IDs": df["Order ID"].is_unique,
    "Valid discount range (0–1)": df["Discount"].between(0, 1).all(),
    "Ship date not before order date": (df["Ship Date"] >= df["Order Date"]).all(),
}
for name, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'}: {name}")
