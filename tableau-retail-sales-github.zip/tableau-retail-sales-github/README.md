# Data Analysis and Visualization Using Tableau
### Retail Sales Analysis Project for India (2023–2025)

A beginner-friendly Tableau project that explores retail sales, profit, product categories, regional performance, customer segments, shipping, and discounts.

> **Dataset note:** `Retail_Sales_India.csv` is synthetic sample data created for this educational project. It is not real company data. The dataset has 1,200 order records and uses Indian states, cities, and INR-style values. Do not present it as real business data.

## Repository contents

- `Retail_Sales_India.csv` — dataset to import into Tableau.
- `analyze_data.py` — Python script for checking data quality and calculating summary metrics.
- `requirements.txt` — Python dependency for the validation script.
- `Data Analysis and Visualization Using Tableau – Project Report.pdf` — project report provided with the project.
- `README.md` — setup instructions and project documentation.

## Project objectives

- Analyze sales and profit over time.
- Compare categories, sub-categories, regions, states, and customer segments.
- Explore the relationship between discounts and profit.
- Build an interactive Tableau dashboard with KPI cards and filters.
- Validate summary values against the source CSV.

## Tools and requirements

- Tableau Desktop or Tableau Public
- Windows 10/11 (64-bit) or supported macOS
- Recommended: 8–16 GB RAM
- Optional: Python 3.9+ to run the validation script

## Dataset fields

| Column | Description |
|---|---|
| Order ID | Unique order identifier |
| Order Date | Date the order was placed |
| Ship Date | Date the order was shipped |
| Ship Mode | Shipping service level |
| Customer ID | Customer code |
| Segment | Consumer, Corporate, or Home Office |
| Region | Sales region in India |
| State | Indian state or union territory |
| City | Delivery city |
| Category | Furniture, Office Supplies, or Technology |
| Sub Category | Product sub-category |
| Sales | Sales value after discount |
| Quantity | Number of units |
| Discount | Discount as a fraction (0.20 = 20%) |
| Profit | Profit or loss value |

## Getting started in Tableau

1. Download or clone this repository.
2. Open Tableau Public or Tableau Desktop.
3. Choose **Connect → To a File → Text File**.
4. Select `Retail_Sales_India.csv`.
5. Check that `Order Date` and `Ship Date` are dates and that `Sales`, `Quantity`, `Discount`, and `Profit` are numeric.
6. Build the worksheets described below.
7. Create a dashboard and add filters for Year, Region, Category, and Segment.

## Suggested worksheets

1. **KPI Sales** — `SUM(Sales)`
2. **KPI Profit** — `SUM(Profit)`
3. **KPI Profit Ratio** — `SUM(Profit) / SUM(Sales)`
4. **KPI Orders** — `COUNTD(Order ID)`
5. **Sales Trend** — monthly sales over time, colored by year
6. **Category Performance** — sales and profit by category
7. **Sub-Category Profit** — profit by sub-category, colored by positive/negative profit
8. **Segment Share** — sales share by customer segment
9. **State Map** — sales by state; set State's geographic role and Country to India if required
10. **Region Profit** — profit ratio by region
11. **Discount Impact** — profit by discount band
12. **Top States** — top 10 states by sales

## Useful Tableau calculated fields

**Profit Ratio**
```text
SUM([Profit]) / SUM([Sales])
```

**Orders**
```text
COUNTD([Order ID])
```

**Average Order Value**
```text
SUM([Sales]) / COUNTD([Order ID])
```

**Shipping Days**
```text
DATEDIFF('day', [Order Date], [Ship Date])
```

**Profit Status**
```text
IF SUM([Profit]) < 0 THEN "Loss" ELSE "Profit" END
```

**Discount Band**
```text
IF [Discount] = 0 THEN "0% (No discount)"
ELSEIF [Discount] <= 0.10 THEN "1–10%"
ELSEIF [Discount] <= 0.20 THEN "11–20%"
ELSE "21–40%"
END
```

## Optional data validation with Python

```bash
pip install -r requirements.txt
python analyze_data.py
```

The script reports dataset dimensions, totals, summary tables, and basic quality checks. Treat its output as the source of truth for the CSV currently in this repository.

## Dashboard layout idea

- Header: **Retail Sales Performance Dashboard (2023–2025)**
- Filters: Year, Region, Category, Segment
- KPI cards: Sales, Profit, Profit Ratio, Orders
- Middle row: Monthly Sales Trend and Sales by State
- Lower rows: Category Performance, Sub-Category Profit, Segment Share, Discount Impact, Top States

Use a consistent color scheme, readable labels, INR currency formatting, and tooltips. Make charts filter one another where useful.

## Limitations

- The dataset is synthetic and limited to 1,200 order records.
- The project is descriptive; it does not provide a production forecast.
- Geographic recognition can vary by Tableau version and may require setting geographic roles manually.
- This repository contains the data and instructions, not a completed Tableau `.twbx` workbook. Add your own workbook and dashboard screenshots after building them in Tableau.

## Publishing to GitHub

1. Create a new GitHub repository, for example `tableau-retail-sales-analysis`.
2. Upload all files in this folder, or use Git:
   ```bash
   git init
   git add .
   git commit -m "Add Tableau retail sales analysis project"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/tableau-retail-sales-analysis.git
   git push -u origin main
   ```
3. Replace `YOUR-USERNAME` with your GitHub username.
4. After creating your dashboard in Tableau, add screenshots to a `screenshots/` folder and include a public Tableau link in this README if you publish the workbook.

## Credits and references

- [Tableau Help](https://help.tableau.com/)
- [Tableau Public](https://public.tableau.com/)
- [Tableau Training](https://www.tableau.com/learn/training)
